(() => {
  const seen = new WeakSet();

  function send(payload) {
    try {
      chrome.runtime.sendMessage({
        source: "CHROME_UPLOAD_DETECTOR",
        payload
      });
    } catch {}
  }

  function emit(type, file, input) {
    send({
      type,
      filename: file?.name || "",
      size: Number(file?.size || 0),
      mime: file?.type || "",
      page_url: location.href,
      page_title: document.title,
      input_name: input?.name || "",
      input_id: input?.id || "",
      timestamp: new Date().toISOString()
    });
  }

  function hook(input) {
    if (!(input instanceof HTMLInputElement) ||
        input.type !== "file" || seen.has(input)) return;

    seen.add(input);

    input.addEventListener("change", () => {
      for (const file of Array.from(input.files || [])) {
        emit("file_selected", file, input);
      }
    }, true);
  }

  function scan(root = document) {
    try {
      root.querySelectorAll?.('input[type="file"]').forEach(hook);
    } catch {}
  }

  scan();

  new MutationObserver(mutations => {
    for (const mutation of mutations) {
      for (const node of mutation.addedNodes) {
        if (node.nodeType !== Node.ELEMENT_NODE) continue;
        if (node.matches?.('input[type="file"]')) hook(node);
        scan(node);
      }
    }
  }).observe(document.documentElement || document, {
    childList: true,
    subtree: true
  });

  document.addEventListener("submit", event => {
    const form = event.target;
    if (!(form instanceof HTMLFormElement)) return;

    form.querySelectorAll('input[type="file"]').forEach(input => {
      for (const file of Array.from(input.files || [])) {
        emit("upload_submit", file, input);
      }
    });
  }, true);
})();